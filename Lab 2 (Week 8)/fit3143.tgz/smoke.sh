#!/bin/bash
#SBATCH --job-name=fit3143-smoke
#SBATCH --time=00:05:00
#SBATCH --partition=defq
#SBATCH --nodes=2
#SBATCH --ntasks=4
#SBATCH --ntasks-per-node=2
#SBATCH --cpus-per-task=4
#SBATCH --mem-per-cpu=1G
#SBATCH --output=smoke-%j.out

module load gcc/11.2.0
module load openmpi/4.1.5-gcc-11.2.0-ux65npg

N=10000000
echo "host: $(hostname)   nodes: $SLURM_JOB_NODELIST"
echo "cores visible to this task: $SLURM_CPUS_PER_TASK"
echo

echo "--- serial baseline ---"
echo $N | ./lab1_serial | tail -2

echo "--- task1: pure MPI, 4 processes across 2 nodes ---"
srun --ntasks=4 --cpus-per-task=1 ./task1_mpi $N

echo "--- task2: hybrid, 4 processes x 4 threads across 2 nodes ---"
export OMP_NUM_THREADS=$SLURM_CPUS_PER_TASK
srun --ntasks=4 --cpus-per-task=4 ./task2_hybrid $N

echo
echo "--- verify all three agree ---"
wc -l primes_output.txt
