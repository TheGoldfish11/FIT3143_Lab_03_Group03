#!/bin/bash
#SBATCH --job-name=fit3143-hybrid
#SBATCH --time=00:28:00
#SBATCH --partition=defq
#SBATCH --nodes=2
#SBATCH --ntasks-per-node=16
#SBATCH --cpus-per-task=1
#SBATCH --output=sweep_hybrid-%j.out
# Graphs 4 & 5: how the process/thread split affects the hybrid at a fixed
# total worker count, and hybrid vs pure MPI at matched worker counts.

module load gcc/11.2.0 openmpi/4.1.5-gcc-11.2.0-ux65npg
N=40000000
CSV=results_hybrid.csv
echo "n,impl,procs,threads,workers,nodes,seconds" > $CSV
t_of() { sed -n 's/.*time=\([0-9.]*\).*/\1/p' | tail -1; }

T=$(echo $N | ./lab1_serial | sed -n 's/.*Time taken: \([0-9.]*\).*/\1/p')
echo "$N,serial,1,1,1,1,$T" >> $CSV

# every process x thread split that totals 2, 4, 8, 16 or 32 workers
for P in 1 2 4 8 16 32; do
  for TH in 1 2 4 8 16; do
    W=$(( P * TH ))
    [ $W -gt 32 ] && continue
    [ $P -gt 32 ] && continue
    ND=1; [ $W -gt 16 ] && ND=2
    [ $P -gt 16 ] && ND=2
    export OMP_NUM_THREADS=$TH
    T=$(srun --nodes=$ND --ntasks=$P --cpus-per-task=$TH ./task2_hybrid $N 2>/dev/null | t_of)
    [ -n "$T" ] && echo "$N,hybrid,$P,$TH,$W,$ND,$T" >> $CSV
    echo "hybrid ${P}x${TH} done" >&2
  done
done
echo "=== $CSV ==="; cat $CSV
