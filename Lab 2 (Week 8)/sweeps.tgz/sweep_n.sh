#!/bin/bash
#SBATCH --job-name=fit3143-sweepn
#SBATCH --time=00:28:00
#SBATCH --partition=defq
#SBATCH --nodes=2
#SBATCH --ntasks-per-node=16
#SBATCH --cpus-per-task=1
#SBATCH --output=sweep_n-%j.out
# Graphs 1 & 2: runtime and speedup vs n, all implementations at 16 workers.
# 30 values of n, chosen so the serial baseline always exceeds 1 second.

module load gcc/11.2.0 openmpi/4.1.5-gcc-11.2.0-ux65npg
CSV=results_n.csv
echo "n,impl,workers,nodes,seconds,primes" > $CSV

t_of() { sed -n 's/.*[Tt]ime[ =]*\([0-9.]*\).*/\1/p' | tail -1; }

for i in $(seq 0 29); do
  N=$(( 20000000 + i * 2000000 ))          # 2e7 .. 7.8e7, 30 values

  # serial, one core
  T=$(echo $N | ./lab1_serial | t_of)
  echo "$N,serial,1,1,$T,-" >> $CSV

  # POSIX threads - shared memory, so confined to ONE node
  T=$(printf "$N\n16\n" | srun --nodes=1 --ntasks=1 --cpus-per-task=16 ./lab1_pthread | t_of)
  echo "$N,pthreads,16,1,$T,-" >> $CSV

  # OpenMP - also one node only
  T=$(echo $N | OMP_NUM_THREADS=16 srun --nodes=1 --ntasks=1 --cpus-per-task=16 ./lab1_openmp | t_of)
  echo "$N,openmp,16,1,$T,-" >> $CSV

  # pure MPI - 16 processes spread over BOTH nodes
  OUT=$(srun --nodes=2 --ntasks=16 --cpus-per-task=1 ./task1_mpi $N)
  echo "$N,mpi,16,2,$(echo "$OUT" | t_of),$(echo "$OUT" | sed -n 's/.*found=\([0-9]*\).*/\1/p')" >> $CSV

  # hybrid - 4 processes x 4 threads over both nodes
  export OMP_NUM_THREADS=4
  OUT=$(srun --nodes=2 --ntasks=4 --cpus-per-task=4 ./task2_hybrid $N)
  echo "$N,hybrid,16,2,$(echo "$OUT" | t_of),$(echo "$OUT" | sed -n 's/.*found=\([0-9]*\).*/\1/p')" >> $CSV

  echo "done n=$N" >&2
done
echo "=== $CSV ==="; cat $CSV
