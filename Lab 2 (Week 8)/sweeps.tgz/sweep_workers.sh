#!/bin/bash
#SBATCH --job-name=fit3143-sweepw
#SBATCH --time=00:28:00
#SBATCH --partition=defq
#SBATCH --nodes=2
#SBATCH --ntasks-per-node=16
#SBATCH --cpus-per-task=1
#SBATCH --output=sweep_workers-%j.out
# Graphs 3 & 6: speedup vs worker count at fixed n.
# Shared-memory implementations stop at 16 (one node's cores); MPI continues to 32.

module load gcc/11.2.0 openmpi/4.1.5-gcc-11.2.0-ux65npg
N=40000000
CSV=results_workers.csv
echo "n,impl,workers,nodes,seconds" > $CSV
t_of() { sed -n 's/.*[Tt]ime[ =]*\([0-9.]*\).*/\1/p' | tail -1; }

T=$(echo $N | ./lab1_serial | t_of); echo "$N,serial,1,1,$T" >> $CSV

for W in 1 2 4 6 8 10 12 14 16; do
  T=$(printf "$N\n$W\n" | srun --nodes=1 --ntasks=1 --cpus-per-task=16 ./lab1_pthread | t_of)
  echo "$N,pthreads,$W,1,$T" >> $CSV
  T=$(echo $N | OMP_NUM_THREADS=$W srun --nodes=1 --ntasks=1 --cpus-per-task=16 ./lab1_openmp | t_of)
  echo "$N,openmp,$W,1,$T" >> $CSV
done

for W in 1 2 4 6 8 10 12 14 16 20 24 28 32; do
  ND=1; [ $W -gt 16 ] && ND=2
  T=$(srun --nodes=$ND --ntasks=$W --cpus-per-task=1 ./task1_mpi $N | t_of)
  echo "$N,mpi,$W,$ND,$T" >> $CSV
  echo "mpi w=$W done" >&2
done
echo "=== $CSV ==="; cat $CSV
